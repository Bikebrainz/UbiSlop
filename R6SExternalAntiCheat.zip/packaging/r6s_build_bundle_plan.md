# Build Plan

How to zip and structure the project.