# Packaging Checklist

- [x] PyInstaller
- [x] NSIS
