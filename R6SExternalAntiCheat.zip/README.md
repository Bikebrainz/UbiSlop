# R6S External Anti-Cheat

This is a modular, offline-first behavioral anti-cheat system for Rainbow Six Siege. Built using Python, with optional cloud escalation.
