# Example stub for r6s_local_runner.py
print('Runner')
