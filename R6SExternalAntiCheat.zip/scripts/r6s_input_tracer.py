# Example stub for r6s_input_tracer.py
print('Tracer running')
