# Example stub for r6s_uploader.py
print('Uploader')
