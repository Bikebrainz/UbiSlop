# Example stub for r6s_alert_viewer.py
print('Alert Viewer')
