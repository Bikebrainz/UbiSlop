# Example stub for r6s_screen_capture.py
print('Screen Capture')
