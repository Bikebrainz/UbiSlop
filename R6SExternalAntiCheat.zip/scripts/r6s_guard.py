# Example stub for r6s_guard.py
print('Guard running')
